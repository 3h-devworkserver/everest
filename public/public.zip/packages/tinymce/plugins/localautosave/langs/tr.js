tinyMCE.addI18n('tr', {
    'localautosave.restoreContent' : 'İçeriği geri yükle',
    'localautosave.chooseVersion' : 'Geri yüklemek istediğiniz versiyonu seçiniz',
    'localautosave.chars' : 'karakter',
    'localautosave.clearAll' :  'Kaydedilmiş tüm yedek içeriği temizle',
    'localautosave.noContent' : 'Kaydedilmiş içerik yok.',
    'localautosave.ifRestore' : 'Bu içeriği geri yüklemeniz durumunda, şu anki içerik geri döndürülemeyecek şekilde kaybolacaktır.\n\nBu içeriği geri yüklemek istediğinize emin misiniz?'
});
