tinyMCE.addI18n('en', {
	'localautosave.restoreContent' : 'Restore content',
	'localautosave.chooseVersion' : 'Choose what you want to restore',
	'localautosave.chars' : 'chars',
	'localautosave.clearAll' : 'Discard all stored versions',
	'localautosave.noContent' : 'There is no content available to restore.',
	'localautosave.ifRestore' : 'If you restore the saved content, you will lose all the content that is currently in the editor.\n\nAre you sure you want to restore the saved content?'
});
