tinyMCE.addI18n('pt_BR',{
	'localautosave.restoreContent' : 'Restaurar Conteúdo',
	'localautosave.chooseVersion' : 'Escolha o que deseja restaurar',
	'localautosave.chars' : 'caracteres',
	'localautosave.clearAll' : 'Descartar todas as versões salvas',
	'localautosave.noContent' : 'Não há nenhum conteúdo disponível para restaurar.',
	'localautosave.ifRestore' : 'Se você restaurar o conteúdo salvo, você vai perder todo o conteúdo que está atualmente no editor.\n\nTem certeza de que deseja restaurar o conteúdo salvo?'
});
