tinyMCE.addI18n('de', {
	'localautosave.restoreContent' : 'Inhalt wiederherstellen',
	'localautosave.chooseVersion' : 'Wiederherstellung auswählen',
	'localautosave.chars' : 'Zeichen',
	'localautosave.clearAll' : 'Alle gespeicherten Versionen verwerfen',
	'localautosave.noContent' : 'Kein wiederherstellbarer Inhalt verfügbar.',
	'localautosave.ifRestore' : 'Bei Wiederherstellung des gesicherten Inhalts, geht der aktuelle Inhalt des Editors verloren.\n\nWiederherstellung wirklich durchführen?'
});
